package com.example.Springwithflutter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwithflutterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwithflutterApplication.class, args);
	}

}
